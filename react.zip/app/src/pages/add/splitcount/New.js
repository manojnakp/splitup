import AppBar from "./components/AppBar";
import Box from '@mui/material/Box';
import Form from "./components/Form";

function NewSplitcount() {
    return (
        <div>
            <AppBar />
            <Box component="main" sx={{ marginTop: '4rem', padding: '0.5rem 0' }}>
                <Form method="POST" action="/"></Form>
            </Box>
        </div>

);
}

export default NewSplitcount;
