import MaterialAppBar from "@mui/material/AppBar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";

function AppBar() {
    return (
            <MaterialAppBar sx={{ display: 'flex', flexDirection: 'row', padding: '0.5rem', alignItems: 'center', height: '4rem' }}>
                <IconButton className="material-symbols-outlined" size={"small"} color={"inherit"}>arrow_back</IconButton>
                <Typography variant={"h1"} sx={{ fontSize: 'h6.fontSize', margin: '0.5rem' }}>New Splitcount</Typography>
            </MaterialAppBar>
        );
}

export default AppBar;
