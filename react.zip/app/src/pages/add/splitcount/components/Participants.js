import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Participant, {ByField} from "./participant";

function Participants({ by, plist, setBy, setPlist }) {
    return (
        <>
            <Typography sx={{ margin: '0.5rem', padding: '0.5rem' }} variant="subtitle1">Participants</Typography>
            <Box>
                <ByField by={by} setBy={setBy} />
                {plist.map((index, name) => (
                    <Participant name={name} key={name} index={index} />
                ))}
            </Box>
        </>
    );
}

export default Participants;
