import Box from '@mui/material/Box';
import InputAdornment from '@mui/material/InputAdornment';
import IconButton from "@mui/material/IconButton";
import TitleDesc from "./TitleDesc";
import Participants from "./Participants";
import {useState} from "react";

function ClearButton({ onclick }) {
    return (
        <InputAdornment position="end">
            <IconButton onClick={onclick} className="material-symbols-outlined">close</IconButton>
        </InputAdornment>
    );
}

function Form({action, method}) {
    const [plist, setPlist] = useState([]);
    const [by, setBy] = useState('Alex');
    return (
        <Box component="form" action={action} method={method} sx={{ backgroundColor: '#d1d5db' }}>
            <TitleDesc btn={ClearButton} />
            <Participants plist={plist} by={by} setPlist={setPlist} setBy={setBy} />
        </Box>
    )
}

export default Form;
