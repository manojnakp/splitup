import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import {useState} from "react";

function TitleDesc({ btn: ClearButton }) {
    const [title, setTitle] = useState('Splitcount title');
    const [desc, setDesc] = useState('Splitcount description');
    const validateTitle = (value) => {
        if (value.trim().length === 0) {
            return 'Title should be at least 1 character long';
        }
        return false;
    }
    return (
        <Box sx={{padding: '1rem', backgroundColor: '#fff', display: 'flex', flexDirection: 'column'}}>
            <TextField
                sx={{margin: '1rem 3rem'}}
                variant="outlined"
                id="title"
                label="Title"
                value={title}
                maxLength="50"
                onChange={(event) => {
                    setTitle(event.target.value)
                }}
                onBlur={() => {
                    setTitle(title.trim())
                }}
                InputProps={{
                    endAdornment: <ClearButton onclick={() => {
                        setTitle('')
                    }}/>
                }}
                error={validateTitle(title)}
                helperText={validateTitle(title)}
                required/>
            <TextField
                sx={{margin: '1rem 3rem'}}
                variant="outlined"
                id="desc"
                label="Description"
                value={desc}
                onChange={(event) => {
                    setDesc(event.target.value)
                }}
                onBlur={() => {
                    setDesc(desc.trim())
                }}
                InputProps={{
                    endAdornment: <ClearButton onclick={() => {
                        setDesc('')
                    }}/>
                }}
                minRows={2}
                maxLength="500"
                multiline
                required/>
        </Box>
    );
}

export default TitleDesc;
