import InputAdornment from "@mui/material/InputAdornment";
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import {useState} from "react";

function MaterialButton({ icon, onclick }) {
    return (
        <InputAdornment position="end">
            <IconButton onClick={onclick} className="material-symbols-outlined">{icon}</IconButton>
        </InputAdornment>
    );
}

function ByField({ by, setBy }) {
    return (
        <Box sx={{ margin: '1rem 3rem', display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
            <TextField
                sx={{ flexGrow: 1, margin: '1rem 0' }}
                variant="outlined"
                onChange={(event) => {setBy(event.target.value)}}
                value={by}
                InputProps={{
                    endAdornment: <MaterialButton icon="close" onclick={() => {
                        setBy('')
                    }}/>
                }}
                onBlur={() => {
                    setBy(by.trim())
                }}
                readOnly={true}
                />
        </Box>
    )
}
function Participant({ name }) {
    return (
        <div>Hello {name}</div>
    )
}
export default Participant;
export {
    ByField
};
