import NewSplitcount from './pages/add/splitcount/New';

function App() {
  return (
    <div className="App">
        <NewSplitcount />
    </div>
  );
}

export default App;
